# OnePlus 13 Network Switch (5G / 4G Dual SIM)

A custom Android Quick Settings cycling tile for the **OnePlus 13** (OxygenOS 15 / Snapdragon 8 Elite).
Alternates between **Preferred 5G** and **Preferred 4G** across **both SIMs simultaneously**.

## Zero Root & Zero Shizuku Architecture
Unlike traditional network switchers that require Magisk/KernelSU or a running Shizuku daemon, this application utilizes Android's `android.permission.WRITE_SECURE_SETTINGS` mechanism combined with Qualcomm X80 modem RIL modes.

Once granted via a single ADB command from any computer, the permission is permanent across phone reboots until the app is uninstalled.

## Build Requirements
- Android Studio Ladybug (2024.2.1+) or newer
- JDK 17
- Android SDK 35 (Android 15)

## Quick Build Steps
```bash
# 1. Clone or extract project
cd OnePlusNetworkSwitch

# 2. Build debug APK
./gradlew assembleDebug

# 3. Install directly to connected OnePlus 13
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

## One-Time ADB Permission Grant
Connect OnePlus 13 to your computer via USB (with USB Debugging enabled in Developer Options):

```bash
adb shell pm grant com.oneplus.networkswitch android.permission.WRITE_SECURE_SETTINGS
adb shell pm grant com.oneplus.networkswitch android.permission.READ_PHONE_STATE
```

### Important OxygenOS 15 Note
In OnePlus 13 **Settings > Developer Options**:
Ensure **"Disable permission monitoring"** is turned **ON**. This allows Android to accept background `Settings.Global` updates without throwing a ColorOS SecurityException.

## Adding the Quick Settings Tile
1. Pull down the notification shade twice.
2. Tap the Pencil / Edit icon.
3. Locate **5G/4G Switch** and drag it to your active tiles.
4. Tap the tile anytime to seamlessly switch between 5G and 4G across both SIMs!

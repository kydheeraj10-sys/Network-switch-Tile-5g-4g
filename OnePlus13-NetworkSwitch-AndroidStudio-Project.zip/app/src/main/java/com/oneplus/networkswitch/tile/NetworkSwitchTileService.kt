package com.oneplus.networkswitch.tile

import android.graphics.drawable.Icon
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.util.Log
import android.widget.Toast
import com.oneplus.networkswitch.R
import com.oneplus.networkswitch.telephony.DualSimHelper
import com.oneplus.networkswitch.telephony.NetworkMode
import com.oneplus.networkswitch.telephony.NetworkModeManager

/**
 * Quick Settings Tile for OnePlus 13 (OxygenOS 15).
 * Alternates between Preferred 5G (NR/LTE/WCDMA/GSM) and Preferred 4G (LTE/WCDMA/GSM)
 * across both SIMs simultaneously without root or Shizuku.
 *
 * Requires one-time ADB permission:
 * adb shell pm grant com.oneplus.networkswitch android.permission.WRITE_SECURE_SETTINGS
 */
class NetworkSwitchTileService : TileService() {

    companion object {
        private const val TAG = "OnePlusNetworkTile"
    }

    private lateinit var networkManager: NetworkModeManager
    private lateinit var dualSimHelper: DualSimHelper

    override fun onCreate() {
        super.onCreate()
        networkManager = NetworkModeManager(applicationContext)
        dualSimHelper = DualSimHelper(applicationContext)
        Log.d(TAG, "NetworkSwitchTileService initialized for OnePlus 13")
    }

    /**
     * Called when the tile becomes visible in the Quick Settings shade.
     * Refreshes current state from system settings.
     */
    override fun onStartListening() {
        super.onStartListening()
        updateTileUI()
    }

    /**
     * Called when the user taps the Quick Settings tile.
     * Alternates preferred network mode on both active SIMs.
     */
    override fun onClick() {
        super.onClick()

        val tile = qsTile ?: return

        // 1. Check for required permission
        if (!networkManager.hasPermission()) {
            provideHapticFeedback(error = true)
            Toast.makeText(
                this,
                "Permission required! Run ADB command:\nadb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS",
                Toast.LENGTH_LONG
            ).show()
            updateTileUI()
            return
        }

        provideHapticFeedback(error = false)

        // 2. Determine target mode (Cycle: If currently 5G -> Switch to 4G; If currently 4G -> Switch to 5G)
        val currentMode = networkManager.getCurrentMode(targetSimSlot = DualSimHelper.SIM_SLOT_BOTH)
        val targetMode = if (currentMode == NetworkMode.PREFERRED_5G) {
            NetworkMode.PREFERRED_4G
        } else {
            NetworkMode.PREFERRED_5G
        }

        // 3. Apply to both SIM slots on OnePlus 13
        val success = networkManager.applyNetworkMode(targetMode, targetSimSlot = DualSimHelper.SIM_SLOT_BOTH)

        if (success) {
            val simCount = dualSimHelper.getActiveSimCount()
            val simLabel = if (simCount > 1) "SIM 1 & SIM 2" else "SIM 1"
            val modeLabel = if (targetMode == NetworkMode.PREFERRED_5G) "5G Preferred" else "4G (LTE) Preferred"

            Toast.makeText(this, "$modeLabel enabled on $simLabel", Toast.LENGTH_SHORT).show()
            Log.i(TAG, "Successfully toggled OnePlus 13 to $modeLabel for $simLabel")
        } else {
            Toast.makeText(this, "Failed to switch network mode. Check OxygenOS settings.", Toast.LENGTH_SHORT).show()
            Log.e(TAG, "Failed to apply network mode: $targetMode")
        }

        // 4. Update the tile visuals immediately
        updateTileUI()
    }

    /**
     * Updates Tile icon, label, subtitle and state based on real hardware state.
     */
    private fun updateTileUI() {
        val tile = qsTile ?: return

        if (!networkManager.hasPermission()) {
            tile.state = Tile.STATE_UNAVAILABLE
            tile.label = getString(R.string.tile_label_no_perm)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                tile.subtitle = getString(R.string.tile_subtitle_need_adb)
            }
            tile.icon = Icon.createWithResource(this, R.drawable.ic_tile_4g)
            tile.updateTile()
            return
        }

        val activeMode = networkManager.getCurrentMode(targetSimSlot = DualSimHelper.SIM_SLOT_BOTH)
        val simCount = dualSimHelper.getActiveSimCount()

        val subtitleText = when {
            simCount >= 2 -> "Both SIMs (1 & 2)"
            simCount == 1 -> "SIM 1 Active"
            else -> "No Active SIM"
        }

        when (activeMode) {
            NetworkMode.PREFERRED_5G -> {
                tile.state = Tile.STATE_ACTIVE
                tile.label = getString(R.string.tile_label_5g)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = subtitleText
                }
                tile.icon = Icon.createWithResource(this, R.drawable.ic_tile_5g)
            }
            NetworkMode.PREFERRED_4G -> {
                tile.state = Tile.STATE_INACTIVE
                tile.label = getString(R.string.tile_label_4g)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    tile.subtitle = "$subtitleText • Battery Saver"
                }
                tile.icon = Icon.createWithResource(this, R.drawable.ic_tile_4g)
            }
        }

        tile.updateTile()
    }

    private fun provideHapticFeedback(error: Boolean) {
        val vibrator = getSystemService(Vibrator::class.java) ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val effect = if (error) {
                VibrationEffect.createPredefined(VibrationEffect.EFFECT_HEAVY_CLICK)
            } else {
                VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
            }
            vibrator.vibrate(effect)
        }
    }
}

package com.oneplus.networkswitch.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.oneplus.networkswitch.telephony.DualSimHelper
import com.oneplus.networkswitch.telephony.NetworkMode
import com.oneplus.networkswitch.telephony.NetworkModeManager
import com.oneplus.networkswitch.telephony.SimSlotInfo
import com.oneplus.networkswitch.ui.theme.OnePlusTheme

class MainActivity : ComponentActivity() {

    private lateinit var networkManager: NetworkModeManager
    private lateinit var dualSimHelper: DualSimHelper

    private val requestPhonePermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        // Trigger UI refresh
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        networkManager = NetworkModeManager(applicationContext)
        dualSimHelper = DualSimHelper(applicationContext)

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPhonePermission.launch(Manifest.permission.READ_PHONE_STATE)
        }

        setContent {
            OnePlusTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MainScreen(
                        networkManager = networkManager,
                        dualSimHelper = dualSimHelper,
                        onRefresh = {
                            // recompose
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    networkManager: NetworkModeManager,
    dualSimHelper: DualSimHelper,
    onRefresh: () -> Unit
) {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(networkManager.hasPermission()) }
    var currentMode by remember { mutableStateOf(networkManager.getCurrentMode()) }
    var simSlots by remember { mutableStateOf(dualSimHelper.getSimDetails()) }

    fun refreshState() {
        hasPermission = networkManager.hasPermission()
        currentMode = networkManager.getCurrentMode()
        simSlots = dualSimHelper.getSimDetails()
        onRefresh()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "OnePlus 13 Network Switcher",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "OxygenOS 15 • Snapdragon 8 Elite",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { refreshState() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Permission Banner
            PermissionCard(
                hasPermission = hasPermission,
                onCopyAdb = {
                    copyToClipboard(
                        context,
                        "adb shell pm grant com.oneplus.networkswitch android.permission.WRITE_SECURE_SETTINGS"
                    )
                },
                onRecheck = { refreshState() }
            )

            // Current Mode Live Toggle Card
            ModeToggleCard(
                currentMode = currentMode,
                hasPermission = hasPermission,
                onToggle = {
                    val next = if (currentMode == NetworkMode.PREFERRED_5G) {
                        NetworkMode.PREFERRED_4G
                    } else {
                        NetworkMode.PREFERRED_5G
                    }
                    val ok = networkManager.applyNetworkMode(next)
                    if (ok) {
                        currentMode = next
                        Toast.makeText(context, "Applied ${next.name} to all active SIMs", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Failed. Check ADB permission", Toast.LENGTH_SHORT).show()
                    }
                    refreshState()
                }
            )

            // Dual SIM Status Section
            DualSimCard(simSlots = simSlots)

            // Quick Settings Tile Setup Guide
            TileInstructionsCard()

            // OxygenOS 15 Special Optimization Notes
            OxygenOsTipsCard()
        }
    }
}

@Composable
fun PermissionCard(
    hasPermission: Boolean,
    onCopyAdb: () -> Unit,
    onRecheck: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (hasPermission) Color(0xFF1B3B2B) else Color(0xFF3B1F20)
        ),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (hasPermission) Icons.Default.CheckCircle else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (hasPermission) Color(0xFF4ADE80) else Color(0xFFF87171),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (hasPermission) "ADB Permission Granted" else "ADB Permission Required",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (hasPermission) Color(0xFF4ADE80) else Color(0xFFF87171)
                )
            }

            if (!hasPermission) {
                Text(
                    text = "Android restricts network mode switching. Grant WRITE_SECURE_SETTINGS once via PC terminal without Root or Shizuku:",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.9f)
                )

                Surface(
                    color = Color.Black.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onCopyAdb() }
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "adb shell pm grant com.oneplus.networkswitch android.permission.WRITE_SECURE_SETTINGS",
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                            color = Color(0xFF93C5FD),
                            modifier = Modifier.weight(1f)
                        )
                        Icon(
                            Icons.Default.ContentCopy,
                            contentDescription = "Copy",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Button(
                    onClick = onRecheck,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE50914)),
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Verify Permission")
                }
            } else {
                Text(
                    text = "System is authorized to cycle preferred network modes instantly from the Quick Settings shade.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
fun ModeToggleCard(
    currentMode: NetworkMode,
    hasPermission: Boolean,
    onToggle: () -> Unit
) {
    val is5G = currentMode == NetworkMode.PREFERRED_5G
    val animatedBg by animateColorAsState(
        targetValue = if (is5G) Color(0xFF0F2B48) else Color(0xFF1E293B),
        label = "bg"
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = animatedBg),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Live Network Mode",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(if (is5G) Color(0xFF0070F3) else Color(0xFF475569)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (is5G) "5G" else "4G",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (is5G) "5G Preferred (NR/LTE Auto)" else "4G Preferred (LTE/WCDMA Only)",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                Text(
                    text = if (is5G) "High throughput • Low latency • Active Dual-SIM" else "Max battery life • Cooler device • Stable fallback",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.7f)
                )
            }

            Button(
                onClick = onToggle,
                enabled = hasPermission,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (is5G) Color(0xFF3B82F6) else Color(0xFFE50914)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Sync, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (is5G) "Switch to 4G Preferred" else "Switch to 5G Preferred",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun DualSimCard(simSlots: List<SimSlotInfo>) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.SimCard, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "OnePlus 13 Dual-SIM Status",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }

            simSlots.forEachIndexed { index, slot ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(if (slot.isActive) Color(0xFFE50914) else Color.Gray),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "S${index + 1}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = slot.displayName,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                            )
                            Text(
                                text = if (slot.isActive) "Carrier: ${slot.carrierName}" else "Slot is empty",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Surface(
                        color = if (slot.isActive) Color(0xFF10B981).copy(alpha = 0.2f) else Color.Gray.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (slot.isActive) "Active" else "Inactive",
                            color = if (slot.isActive) Color(0xFF10B981) else Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TileInstructionsCard() {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "How to add the Quick Settings Tile",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "1. Swipe down twice from the top of your OnePlus 13 screen to open Quick Settings.\n2. Tap the pencil (Edit) icon at the top right.\n3. Scroll down to find '5G/4G Switch'.\n4. Drag the tile into your active top grid.\n5. Tap the tile at any time to instantly switch both SIMs!",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun OxygenOsTipsCard() {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = "OxygenOS 15 / ColorOS Note",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Color(0xFFF59E0B)
            )
            Text(
                text = "In OxygenOS 15 Developer Options, ensure 'Disable permission monitoring' is turned ON. This prevents OxygenOS's aggressive permission guard from blocking background Settings.Global writes.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

fun copyToClipboard(context: Context, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("ADB Command", text)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "Command copied to clipboard!", Toast.LENGTH_SHORT).show()
}

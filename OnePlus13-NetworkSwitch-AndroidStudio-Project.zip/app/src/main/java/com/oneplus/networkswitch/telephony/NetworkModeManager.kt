package com.oneplus.networkswitch.telephony

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.util.Log

enum class NetworkMode {
    PREFERRED_5G,
    PREFERRED_4G
}

/**
 * Manages reading and writing preferred network modes on OnePlus 13 (Snapdragon 8 Elite / OxygenOS 15).
 * Works by writing to Settings.Global and triggering telephony bitmask synchronization.
 */
class NetworkModeManager(private val context: Context) {

    companion object {
        private const val TAG = "NetworkModeManager"

        /**
         * OxygenOS 14/15 & Qualcomm RIL preferred network mode constants:
         * 26: NR / LTE / TDSCDMA / CDMA / EvDo / GSM / WCDMA (Global 5G)
         * 33: NR / LTE / CDMA / EvDo / GSM / WCDMA
         * 9:  LTE / GSM / WCDMA (Standard 4G preferred)
         * 10: LTE / CDMA / EvDo / GSM / WCDMA (Global 4G preferred)
         */
        const val RIL_MODE_5G_PREFERRED = 26
        const val RIL_MODE_4G_PREFERRED = 9

        // Bitmasks for Android 11-15 (API 30+)
        // TelephonyManager.NETWORK_TYPE_BITMASK_NR = 1 shl 19 (524288)
        // TelephonyManager.NETWORK_TYPE_BITMASK_LTE = 1 shl 12 (4096)
        const val BITMASK_5G = 0x80000 or 0x1000 or 0x40 or 0x8 or 0x10 or 0x2 or 0x1
        const val BITMASK_4G = 0x1000 or 0x40 or 0x8 or 0x10 or 0x2 or 0x1

        // OxygenOS & ColorOS specific Global settings keys
        private const val KEY_PREFERRED_NETWORK_MODE = "preferred_network_mode"
        private const val KEY_PREFERRED_NETWORK_MODE_SIM1 = "preferred_network_mode1"
        private const val KEY_PREFERRED_NETWORK_MODE_SIM2 = "preferred_network_mode2"
        private const val KEY_OPLUS_CUSTOMIZE_NETWORK = "oplus_customize_preferred_network_mode"
    }

    private val cr = context.contentResolver
    private val dualSimHelper = DualSimHelper(context)

    /**
     * Checks if WRITE_SECURE_SETTINGS permission is granted via ADB.
     */
    fun hasPermission(): Boolean {
        return context.checkCallingOrSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
                PackageManager.PERMISSION_GRANTED
    }

    /**
     * Determines the current network mode.
     * Evaluates active SIM subscriptions.
     */
    fun getCurrentMode(targetSimSlot: Int = DualSimHelper.SIM_SLOT_BOTH): NetworkMode {
        val subscriptions = dualSimHelper.getActiveSubscriptions()

        if (subscriptions.isNotEmpty()) {
            for (subInfo in subscriptions) {
                val subId = subInfo.subscriptionId
                val mode = getModeForSubId(subId)
                if (is5GMode(mode)) {
                    return NetworkMode.PREFERRED_5G
                }
            }
        }

        // Fallback to global setting if no subId found
        val globalMode = try {
            Settings.Global.getInt(cr, KEY_PREFERRED_NETWORK_MODE, RIL_MODE_5G_PREFERRED)
        } catch (e: Exception) {
            RIL_MODE_5G_PREFERRED
        }

        return if (is5GMode(globalMode)) NetworkMode.PREFERRED_5G else NetworkMode.PREFERRED_4G
    }

    /**
     * Applies target NetworkMode (5G or 4G) to target SIMs (SIM 1, SIM 2, or Both).
     */
    fun applyNetworkMode(targetMode: NetworkMode, targetSimSlot: Int = DualSimHelper.SIM_SLOT_BOTH): Boolean {
        if (!hasPermission()) {
            Log.e(TAG, "Cannot apply network mode: WRITE_SECURE_SETTINGS permission not granted.")
            return false
        }

        val rilValue = if (targetMode == NetworkMode.PREFERRED_5G) RIL_MODE_5G_PREFERRED else RIL_MODE_4G_PREFERRED
        val bitmaskValue = if (targetMode == NetworkMode.PREFERRED_5G) BITMASK_5G else BITMASK_4G
        var allSucceeded = true

        try {
            // 1. Write the primary global fallback
            Settings.Global.putInt(cr, KEY_PREFERRED_NETWORK_MODE, rilValue)

            // 2. Target specific active SIMs via SubscriptionManager
            val subs = dualSimHelper.getActiveSubscriptions()

            for (subInfo in subs) {
                val slotIndex = subInfo.simSlotIndex
                val subId = subInfo.subscriptionId

                val shouldApply = when (targetSimSlot) {
                    DualSimHelper.SIM_SLOT_SIM1 -> slotIndex == 0
                    DualSimHelper.SIM_SLOT_SIM2 -> slotIndex == 1
                    else -> true // BOTH
                }

                if (shouldApply) {
                    val subSuccess = writeForSubscription(subId, slotIndex, rilValue, bitmaskValue)
                    if (!subSuccess) allSucceeded = false
                }
            }

            // 3. Write OxygenOS / ColorOS specific multi-SIM keys
            if (targetSimSlot == DualSimHelper.SIM_SLOT_BOTH || targetSimSlot == DualSimHelper.SIM_SLOT_SIM1) {
                Settings.Global.putInt(cr, KEY_PREFERRED_NETWORK_MODE_SIM1, rilValue)
            }
            if (targetSimSlot == DualSimHelper.SIM_SLOT_BOTH || targetSimSlot == DualSimHelper.SIM_SLOT_SIM2) {
                Settings.Global.putInt(cr, KEY_PREFERRED_NETWORK_MODE_SIM2, rilValue)
            }

            // 4. Send OnePlus telephony preference update broadcast
            sendPreferenceBroadcast(rilValue)

            Log.i(TAG, "Network mode written: rilValue=$rilValue, slotTarget=$targetSimSlot")
            return allSucceeded
        } catch (e: SecurityException) {
            Log.e(TAG, "SecurityException: permission WRITE_SECURE_SETTINGS revoked or blocked by OS", e)
            return false
        } catch (e: Exception) {
            Log.e(TAG, "Failed to write network settings", e)
            return false
        }
    }

    private fun writeForSubscription(subId: Int, slotIndex: Int, rilValue: Int, bitmaskValue: Int): Boolean {
        return try {
            // Android standard sub-keyed global properties
            Settings.Global.putInt(cr, "preferred_network_mode$subId", rilValue)
            Settings.Global.putLong(cr, "preferred_network_type_bitmask$subId", bitmaskValue.toLong())

            // Reflection-based call to TelephonyManager for immediate modem sync if accessible
            trySetTelephonyBitmask(subId, bitmaskValue)
            true
        } catch (e: Exception) {
            Log.w(TAG, "Error writing subId=$subId", e)
            false
        }
    }

    private fun trySetTelephonyBitmask(subId: Int, bitmask: Int) {
        try {
            val tm = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager ?: return
            val subTm = tm.createForSubscriptionId(subId)
            // Attempt to invoke setPreferredNetworkTypeBitmask via reflection if allowed
            val method = subTm.javaClass.getMethod("setPreferredNetworkTypeBitmask", Long::class.javaPrimitiveType)
            method.isAccessible = true
            method.invoke(subTm, bitmask.toLong())
        } catch (e: Throwable) {
            // Non-fatal: Settings.Global write will trigger Qualcomm RIL update
            Log.d(TAG, "Direct bitmask invocation bypassed: ${e.message}")
        }
    }

    private fun sendPreferenceBroadcast(rilValue: Int) {
        try {
            val intent = Intent("android.intent.action.PREFERENCE_SWITCH_CHANGED").apply {
                putExtra("preference_type", "preferred_network_mode")
                putExtra("preference_value", rilValue)
                setPackage("com.android.phone")
            }
            context.sendBroadcast(intent)
        } catch (e: Exception) {
            // Optional broadcast, ignore if restricted
        }
    }

    private fun getModeForSubId(subId: Int): Int {
        return try {
            Settings.Global.getInt(cr, "preferred_network_mode$subId", -1).let {
                if (it != -1) it else Settings.Global.getInt(cr, KEY_PREFERRED_NETWORK_MODE, RIL_MODE_5G_PREFERRED)
            }
        } catch (e: Exception) {
            RIL_MODE_5G_PREFERRED
        }
    }

    private fun is5GMode(mode: Int): Boolean {
        // Known 5G modes in Android & OnePlus
        return mode == 26 || mode == 33 || mode == 23 || mode == 24 || mode == 25 || mode == 31 || mode == 32
    }
}

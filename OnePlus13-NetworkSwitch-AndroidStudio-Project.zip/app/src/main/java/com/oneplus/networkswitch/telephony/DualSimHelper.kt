package com.oneplus.networkswitch.telephony

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat

/**
 * Handles Dual SIM queries on OnePlus 13 (Dual Nano-SIM / Dual Active 5G).
 */
class DualSimHelper(private val context: Context) {

    companion object {
        const val SIM_SLOT_BOTH = 0
        const val SIM_SLOT_SIM1 = 1
        const val SIM_SLOT_SIM2 = 2
    }

    private val subscriptionManager: SubscriptionManager? by lazy {
        context.getSystemService(Context.TELEPHONY_SERVICE)
        context.getSystemService(SubscriptionManager::class.java)
    }

    @SuppressLint("MissingPermission")
    fun getActiveSubscriptions(): List<SubscriptionInfo> {
        val hasPhoneState = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasPhoneState || subscriptionManager == null) {
            return emptyList()
        }

        return try {
            subscriptionManager?.activeSubscriptionInfoList ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun getActiveSimCount(): Int {
        return getActiveSubscriptions().size
    }

    fun getSimDetails(): List<SimSlotInfo> {
        val list = mutableListOf<SimSlotInfo>()
        val subs = getActiveSubscriptions()

        for (slotIndex in 0..1) {
            val sub = subs.find { it.simSlotIndex == slotIndex }
            if (sub != null) {
                list.add(
                    SimSlotInfo(
                        slotIndex = slotIndex,
                        subscriptionId = sub.subscriptionId,
                        carrierName = sub.carrierName?.toString() ?: "SIM ${slotIndex + 1}",
                        displayName = sub.displayName?.toString() ?: "SIM ${slotIndex + 1}",
                        isEmbedded = sub.isEmbedded,
                        isActive = true
                    )
                )
            } else {
                list.add(
                    SimSlotInfo(
                        slotIndex = slotIndex,
                        subscriptionId = -1,
                        carrierName = "Empty",
                        displayName = "SIM ${slotIndex + 1}",
                        isEmbedded = false,
                        isActive = false
                    )
                )
            }
        }
        return list
    }
}

data class SimSlotInfo(
    val slotIndex: Int,
    val subscriptionId: Int,
    val carrierName: String,
    val displayName: String,
    val isEmbedded: Boolean,
    val isActive: Boolean
)

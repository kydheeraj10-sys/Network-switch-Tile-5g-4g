# Add project specific ProGuard rules here.
-keepclassmembers class com.oneplus.networkswitch.tile.NetworkSwitchTileService {
   public *;
}
-keep class com.oneplus.networkswitch.telephony.** { *; }

#!/usr/bin/env bash
set -e

echo "=========================================="
echo "  OnePlus 13 Network Switch APK Builder"
echo "  Target: OxygenOS 15 (Android 15 / API 35)"
echo "=========================================="

chmod +x gradlew
echo "--> Compiling debug APK..."
./gradlew assembleDebug

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
    echo ""
    echo "SUCCESS! APK generated at:"
    echo "  $APK_PATH"
    echo ""
    echo "To install directly to your connected OnePlus 13:"
    echo "  adb install -r $APK_PATH"
    echo "  adb shell pm grant com.oneplus.networkswitch android.permission.WRITE_SECURE_SETTINGS"
    echo "=========================================="
else
    echo "Build failed or APK not found."
    exit 1
fi

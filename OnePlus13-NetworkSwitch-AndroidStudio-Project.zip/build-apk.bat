@echo off
echo ==========================================
echo   OnePlus 13 Network Switch APK Builder
echo   Target: OxygenOS 15 (Android 15 / API 35)
echo ==========================================

call gradlew.bat assembleDebug

set APK_PATH=app\build\outputs\apk\debug\app-debug.apk
if exist "%APK_PATH%" (
    echo.
    echo SUCCESS! APK generated at:
    echo   %APK_PATH%
    echo.
    echo To install directly to your connected OnePlus 13:
    echo   adb install -r %APK_PATH%
    echo   adb shell pm grant com.oneplus.networkswitch android.permission.WRITE_SECURE_SETTINGS
    echo ==========================================
) else (
    echo Build failed or APK not found.
)
pause
